function index_min_val = min_f_val( OPEN, size_OPEN, goalx, goaly )
% Return the index of the node with minimum f_val

temp_array = [];
k = 1;
flag = 0;
goal_index = 0;
for j = 1:size_OPEN
    if OPEN(j,1)
        temp_array( k, : ) = [ OPEN( j, : ), j];
        if ( OPEN( j, 2 ) == goalx ) && ( OPEN( j, 3 ) == goaly )
            flag = 1;
            goal_index = j;
        end
        k = k + 1;
    end
end
if flag
    index_min_val = goal_index;
end
if size( temp_array ~= 0 )
    [ min_f_val, temp_min ]= min( temp_array( :, 8 ) );
    index_min_val = temp_array( temp_min, 9 );
else
    % OPEN is empty
    index_min_val = -1;
end

end