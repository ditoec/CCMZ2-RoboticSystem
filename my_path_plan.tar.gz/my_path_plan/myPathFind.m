clf;        %clears figures
clc;        %clears console
clear;      %clears workspace
axis equal; %keeps the x and y scale the same
map=[0,0;60,0;60,45;45,45;45,59;106,59;106,105;0,105];  %default map
botSim = BotSim(map);  %sets up a botSim object a map, and debug mode on.

hold on;
botSim.drawMap();

limsMin = min(map); % minimum limits of the map
limsMax = max(map); % maximum limits of the map
dims = limsMax-limsMin; %dimension of the map
res = 10; %sampling resouloution in cm
iterators = dims/res;
iterators = ceil(iterators)+[1 1]; %to counteract 1 based indexing
mapArray = zeros(iterators); %preallocate for speed
hold on
%loops through the grid indexes and tests if they are inside the map
for x = 1:iterators(1)
    for y = 1:iterators(2)
        testPos = limsMin + [x-1 y-1]*res; %to counteract 1 based indexing
        %notice, that i and j have also been swapped here so that the only
        %thing left to do is invert the y axis. 
        mapArray(x,y) = botSim.pointInsideMap(testPos);
        if mapArray(x,y)
            plot(testPos(1),testPos(2),'*b');%inside map
        else
            plot(testPos(1),testPos(2),'ob');%outside map
        end
    end
end

%% My code
startx_user = 40;
starty_user = 20;
goalx_user =  80;
goaly_user = 70;
startx = round( startx_user / res ) + 1;
starty = round( starty_user / res ) + 1;
goalx = round( goalx_user / res ) + 1;
goaly = round( goaly_user / res ) + 1;
plot( (startx-1)*res, (starty-1)*res, 'pk' );
plot( (goalx-1)*res, (goaly-1)*res, 'pr' );
currentx = startx;
currenty = starty;
OPEN = [];
CLOSED = [];
% Include all impassable nodes into CLOSED
size_CLOSED = 0;
for x = 1:iterators( 1 )
    for y = 1:iterators( 2 )
        if ~mapArray( x, y )
            size_CLOSED = size_CLOSED + 1;
            CLOSED( size_CLOSED, 1 ) = x;
            CLOSED( size_CLOSED, 2 ) = y;
        end
    end
end

size_OPEN = 1;
g_val = 0;
h_val = get_distance( startx, starty, goalx, goaly );
f_val = g_val + h_val;
OPEN( size_OPEN, : ) = add2OPEN( startx, starty, startx, starty, g_val, h_val, f_val );
OPEN( size_OPEN, 1 ) = 0; % Delete the starting node from OPEN
size_CLOSED = size_CLOSED + 1; % Add the starting node to CLOSED
CLOSED( size_CLOSED, 1 ) = startx;
CLOSED( size_CLOSED, 2 ) = starty;
no_path = 1; % 1 -- path not found; 0 -- path found

while ( currentx ~= goalx || currenty ~= goaly ) && no_path
    % Expand the frontier
    frontier = expand_frontier( CLOSED, g_val, currentx, currenty, goalx, goaly, iterators(1), iterators(2) );
    size_frontier = size( frontier, 1 );
    % Add the node to OPEN if not included
    % Update f_val if the new value is lower than the old one
    for path_index = 1:size_frontier
        in_OPEN = 0; % 0 -- node not in OPEN; 1 -- node in OPEN
        for j = 1:size_OPEN
            if ( frontier( path_index, 1 ) == OPEN( j, 2 ) ) && ( frontier( path_index, 2 ) == OPEN( j, 3 ) )
                OPEN( j, 8 ) = min( OPEN( j, 8 ), frontier( path_index, 5 ) );
                if OPEN( j, 8 ) == frontier( path_index, 5 )
                    OPEN( j, 4 ) = currentx; % Parent x
                    OPEN( j, 5 ) = currenty; % Parent y
                    OPEN( j, 6 ) = frontier( path_index, 3 ); % g_val
                    OPEN( j, 7 ) = frontier( path_index, 4 ); % h_val
                end
                in_OPEN = 1;
            end
        end
        if ~in_OPEN
            size_OPEN = size_OPEN + 1;
            OPEN( size_OPEN, : ) = add2OPEN( frontier( path_index, 1 ), frontier( path_index, 2 ), currentx, currenty, frontier( path_index, 3 ), frontier( path_index, 4 ), frontier( path_index, 5 ) );
        end
    end
    % Find out the node with the smallest f_val
    index_min_node = min_f_val( OPEN, size_OPEN, goalx, goaly );
    % OPEN is not empty
    if index_min_node ~= -1
        currentx = OPEN( index_min_node, 2 );
        currenty = OPEN( index_min_node, 3 );
        g_val = OPEN( index_min_node, 6 );
        % Add the node to CLOSED
        size_CLOSED = size_CLOSED + 1;
        CLOSED( size_CLOSED, 1 ) = currentx;
        CLOSED( size_CLOSED, 2 ) = currenty;
        % Delete the node from OPEN
        OPEN( index_min_node, 1 )=0;
    else
        % No path exists to the Target
        NoPath = 0;
    end
end
% Get the optimal path
path_index = size( CLOSED, 1 );
my_path = [];
currentx = CLOSED( path_index, 1 );
currenty = CLOSED( path_index, 2 );
path_index = 1;
my_path( path_index, 1 ) = currentx;
my_path( path_index, 2 ) = currenty;
path_index = path_index + 1;

if ( currentx == goalx ) && ( currenty == goaly )
    index_in_OPEN = 0;
    % Traverse OPEN to find the parent nodes
    parentx = OPEN( node_index( OPEN, currentx, currenty ), 4 );
    parenty = OPEN( node_index( OPEN, currentx, currenty ), 5 );
    
    while( parentx ~= startx || parenty ~= starty )
        my_path( path_index, 1 ) = parentx;
        my_path( path_index, 2 ) = parenty;
        % Get the parent of the current node
        index_in_OPEN = node_index( OPEN, parentx, parenty );
        parentx = OPEN( index_in_OPEN, 4) ;
        parenty = OPEN( index_in_OPEN, 5 );
        path_index = path_index + 1;
    end
    final_path = [ startx - 1, starty - 1; fliplr( my_path' )' - 1 ];
else
    final_path = -1;
end

plot( final_path( :, 1 )'*res, final_path( :, 2 )'*res, 'b-' );

num_command = size( my_path, 1 );
% my_command(:,1) -- turn; my_command(:,2) -- move
my_command = zeros( num_command, 2 );
for i = 1:num_command
    my_command
end
