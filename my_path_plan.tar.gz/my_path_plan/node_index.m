function index = node_index( OPEN, currentx, currenty )
% Returns the index of a node in OPEN

i = 1;
while( OPEN( i, 2 ) ~= currentx ) || ( OPEN( i, 3 ) ~= currenty )
    i = i + 1;
end
index = i;

end