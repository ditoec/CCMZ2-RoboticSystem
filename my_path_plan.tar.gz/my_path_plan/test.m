clf;        %clears figures
clc;        %clears console
clear;      %clears workspace

