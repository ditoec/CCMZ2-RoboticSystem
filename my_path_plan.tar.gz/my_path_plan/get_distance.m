function heuristics = get_distance(x_start, y_start, x_goal, y_goal)

x_temp = x_start - x_goal;
y_temp = y_start - y_goal;
x_sum_temp = x_temp*x_temp;
y_sum_temp = y_temp*y_temp;
sum_temp = x_sum_temp + y_sum_temp;
heuristics = sqrt( sum_temp );

end