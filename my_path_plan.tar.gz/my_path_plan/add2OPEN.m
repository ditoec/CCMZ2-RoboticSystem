function node = add2OPEN( x_current, y_current, x_parent, y_parent, g_val, h_val, f_val )
% Add a new node to OPEN

node = [ 1, 8 ];
node( 1, 1 ) = 1; % 1 -- node in OPEN; 0 -- node not in OPEN
node( 1, 2 ) = x_current;
node( 1, 3 ) = y_current;
node( 1, 4 ) = x_parent;
node( 1, 5 ) = y_parent;
node( 1, 6 ) = g_val; % Distance from the starting node
node( 1, 7 ) = h_val; % Distance to the end node
node( 1, 8 ) = f_val; % f_val = h_val + g_val

end