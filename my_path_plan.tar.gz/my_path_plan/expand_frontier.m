function frontier = expand_frontier( CLOSED, g_val, currentx, currenty, goalx, goaly, num_rows, num_cols )
% Expand the frontier

frontier = [];
count_frontier = 1;
size_CLOSED = size( CLOSED, 1 );
for dx = -1:1:1
    for dy = -1:1:1
        if (~dx) && (~dy)
            continue
        end
        temp_x = currentx + dx;
        temp_y = currenty + dy;
        if (temp_x < 1) || (temp_x > num_rows) || (temp_y < 1) || (temp_y > num_cols)
            continue
        end
        no_match = 1; % 1 -- no match found; 0 -- match found
        for count_CLOSED = 1:size_CLOSED
            if temp_x == CLOSED( count_CLOSED, 1 ) && temp_y == CLOSED( count_CLOSED, 2 )
                no_match = 0;
            end
        end
        if no_match
            frontier( count_frontier, 1 ) = temp_x;
            frontier( count_frontier, 2 ) = temp_y;
            % g = distance from the starting node
            frontier( count_frontier, 3 ) = g_val + get_distance( currentx, currenty, temp_x, temp_y );
            % h = distance from the end node
            frontier( count_frontier, 4 ) = get_distance( goalx,goaly,temp_x,temp_y);
            % f = g + h
            frontier( count_frontier, 5 ) = frontier( count_frontier, 3 ) + frontier( count_frontier, 4 );
            count_frontier = count_frontier + 1;
        end
    end
end