function [ currentx, currenty ] = myCurrentGet( frontier, numRows, numCols )
% Get the coordinates of an unvisited position

% found: 0 -- not found; 1 -- found
found = 0; 

for i = 1:numRows
    if found
        break
    end
    for j = 1:numCols
        if frontier(i, j)
            currentx = i;
            currenty = j;
            found = 1;
            break
        end
    end
end

end
